This is GoQuest 9x9 data kindly provided by Tanase-san.

GoQuest
  Google Play : https://play.google.com/store/apps/details?id=fm.wars.goquest&hl=ja&gl=US&pli=1
  App Store : https://apps.apple.com/jp/app/%E5%9B%B2%E7%A2%81%E3%82%AF%E3%82%A8%E3%82%B9%E3%83%88/id834841918